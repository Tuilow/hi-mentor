'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import Link from 'next/link';
import { channelApi } from '@/lib/api';
import type { PublicChannel } from '@/types';
import { commercializationLabel } from '@/lib/courseCommercialization';

/**
 * Converte a URL colada pelo criador (YouTube/Vimeo) numa URL de embed — mesma lógica de
 * /c/[slug] (vídeo da página de vendas), aqui para o vídeo de apresentação do canal.
 */
function toEmbedUrl(url: string): string | null {
  const youtubeMatch = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{6,})/);
  if (youtubeMatch) return `https://www.youtube.com/embed/${youtubeMatch[1]}`;

  const vimeoMatch = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
  if (vimeoMatch) return `https://player.vimeo.com/video/${vimeoMatch[1]}`;

  return null;
}

const platformIcon: Record<string, string> = {
  instagram: '📷',
  youtube: '▶️',
  tiktok: '🎵',
  whatsapp: '💬',
  site: '🔗',
  twitter: '🐦',
  x: '🐦',
  facebook: '📘',
  linkedin: '💼',
};

/**
 * Canal do Criador — vitrine pública em tuilow.com/canal/{handle} com todos os cursos
 * publicados do criador. Cursos grátis aparecem liberados para qualquer um; cursos pagos
 * mostram cadeado até o visitante logar e comprar/matricular (mesma regra do backend,
 * ver GetPublicChannelQueryHandler.IsUnlocked).
 */
export default function PublicChannelPage() {
  const { handle } = useParams<{ handle: string }>();
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    setIsLoggedIn(!!localStorage.getItem('access_token'));
  }, []);

  const { data: channel, isLoading } = useQuery<PublicChannel>({
    queryKey: ['public-channel', handle],
    queryFn: () => channelApi.getByHandle(handle).then(r => r.data),
    enabled: !!handle,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <p className="text-gray-400 text-sm">Carregando...</p>
      </div>
    );
  }

  if (!channel) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center gap-3">
        <p className="text-4xl">😕</p>
        <p className="text-lg font-medium text-gray-700">Canal não encontrado</p>
        <Link href="/" className="text-brand-600 hover:underline text-sm">← Voltar para o início</Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <header className="border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="text-lg font-bold gradient-text">🎓 Tuilow</Link>
          <Link href={isLoggedIn ? '/dashboard' : '/login'}
            className="text-sm text-gray-500 hover:text-gray-800 transition-colors">
            {isLoggedIn ? 'Ir para o painel →' : 'Entrar'}
          </Link>
        </div>
      </header>

      {channel.bannerUrl && (
        <div className="w-full h-40 sm:h-56 bg-gray-100 overflow-hidden">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={channel.bannerUrl} alt="" className="w-full h-full object-cover" />
        </div>
      )}

      <div className="max-w-4xl mx-auto px-4 py-10">
        {/* Perfil do canal */}
        <div className="flex flex-col items-center text-center mb-8">
          {channel.avatarUrl ? (
            <img src={channel.avatarUrl} alt={channel.displayName}
              className="w-24 h-24 rounded-full object-cover mb-4" />
          ) : (
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-brand-500 to-accent-500
                            flex items-center justify-center text-white text-3xl font-bold mb-4">
              {channel.displayName[0]?.toUpperCase()}
            </div>
          )}
          <h1 className="text-2xl font-bold text-gray-800">{channel.displayName}</h1>
          <p className="text-sm text-gray-400 mt-0.5">@{channel.handle}</p>
          {channel.bio && <p className="text-gray-600 mt-3 max-w-lg">{channel.bio}</p>}

          {channel.socialLinks.length > 0 && (
            <div className="flex items-center gap-3 mt-4">
              {channel.socialLinks.map((link, i) => (
                <a key={i} href={link.url} target="_blank" rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors
                             flex items-center justify-center text-lg" title={link.platform}>
                  {platformIcon[link.platform.toLowerCase()] ?? '🔗'}
                </a>
              ))}
            </div>
          )}
        </div>

        {/* Vídeo de apresentação */}
        {channel.introVideoUrl && toEmbedUrl(channel.introVideoUrl) && (
          <div className="mb-10 rounded-xl overflow-hidden aspect-video bg-black">
            <iframe
              src={toEmbedUrl(channel.introVideoUrl)!}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
        )}

        {/* Catálogo de cursos */}
        <h2 className="text-lg font-semibold text-gray-800 mb-4">
          Cursos {channel.courses.length > 0 && `(${channel.courses.length})`}
        </h2>

        {channel.courses.length === 0 ? (
          <div className="card border-gray-200 text-center py-10">
            <p className="text-gray-400 text-sm">Nenhum curso publicado ainda.</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {/* Regra principal (Problema 3): "visualizar" (aparecer nesta grade) ≠ "possuir
                acesso" — todos os cursos publicados do criador aparecem aqui, mas só quem tem
                acesso de fato (course.isUnlocked, calculado no backend por IUserCourseAccessService)
                pode assistir. Vai sempre para /c/{slug}: a própria página de vendas já resolve
                "já matriculado → entra direto no curso" ou "ainda não → matricula/paga", sem
                duplicar essa lógica aqui. */}
            {channel.courses.map(course => (
              <Link key={course.id} href={`/c/${course.slug}`}
                className="card border-gray-200 hover:border-brand-300 transition-colors p-0 overflow-hidden">
                <div className="relative">
                  {course.thumbnailUrl ? (
                    <img src={course.thumbnailUrl} alt={course.title}
                      className="w-full h-36 object-cover" />
                  ) : (
                    <div className="w-full h-36 bg-gradient-to-br from-gray-100 to-gray-50
                                    flex items-center justify-center text-4xl">📚</div>
                  )}
                  {!course.isUnlocked && (
                    <div className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/60
                                    flex items-center justify-center text-white text-xs">🔒</div>
                  )}
                </div>
                <div className="p-4">
                  <p className="text-sm font-semibold text-gray-800 line-clamp-2">{course.title}</p>
                  <p className="text-sm gradient-text font-bold mt-2">
                    {commercializationLabel(course.commercializationState, course.price, course.isFree)}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    {course.isUnlocked ? 'Continuar assistindo →' : '🔒 Comprar curso →'}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
